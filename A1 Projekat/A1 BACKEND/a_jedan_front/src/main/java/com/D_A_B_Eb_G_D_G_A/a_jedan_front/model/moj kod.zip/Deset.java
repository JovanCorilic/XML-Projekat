package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Deset
{
    private String Nameravani_Nacin_Koriscenja_Autorskog_Dela;

    public String getNameravani_Nacin_Koriscenja_Autorskog_Dela ()
    {
        return Nameravani_Nacin_Koriscenja_Autorskog_Dela;
    }

    public void setNameravani_Nacin_Koriscenja_Autorskog_Dela (String Nameravani_Nacin_Koriscenja_Autorskog_Dela)
    {
        this.Nameravani_Nacin_Koriscenja_Autorskog_Dela = Nameravani_Nacin_Koriscenja_Autorskog_Dela;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Nameravani_Nacin_Koriscenja_Autorskog_Dela = "+Nameravani_Nacin_Koriscenja_Autorskog_Dela+"]";
    }
}