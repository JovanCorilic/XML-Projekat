package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Podnosioci
{
    private Zivi_Podnosioci Zivi_Podnosioci;

    private Mrtvi_Podnosioci Mrtvi_Podnosioci;

    private Anonimni_Podnosioci Anonimni_Podnosioci;

    public Mrtvi_Podnosioci getMrtvi_Podnosioci ()
    {
        return Mrtvi_Podnosioci;
    }

    public void setMrtvi_Podnosioci (Mrtvi_Podnosioci Mrtvi_Podnosioci)
    {
        this.Mrtvi_Podnosioci = Mrtvi_Podnosioci;
    }

    public Anonimni_Podnosioci getAnonimni_Podnosioci ()
    {
        return Anonimni_Podnosioci;
    }

    public void setAnonimni_Podnosioci (Anonimni_Podnosioci Anonimni_Podnosioci)
    {
        this.Anonimni_Podnosioci = Anonimni_Podnosioci;
    }

    public Zivi_Podnosioci getZivi_Podnosioci ()
    {
        return Zivi_Podnosioci;
    }

    public void setZivi_Podnosioci (Zivi_Podnosioci Zivi_Podnosioci)
    {
        this.Zivi_Podnosioci = Zivi_Podnosioci;
    }

    @Override
    public String toString()
    {
        return "ClassPojo ["+"Zivi_Podnosioci = "+Zivi_Podnosioci+", Mrtvi_Podnosioci = "+Mrtvi_Podnosioci+", Anonimni_Podnosioci = "+Anonimni_Podnosioci+"]";
    }
}