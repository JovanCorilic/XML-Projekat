package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Anoniman_Podnosilac
{
    private String Delo_Anonimnog_Autora;

    public String getDelo_Anonimnog_Autora ()
    {
        return Delo_Anonimnog_Autora;
    }

    public void setDelo_Anonimnog_Autora (String Delo_Anonimnog_Autora)
    {
        this.Delo_Anonimnog_Autora = Delo_Anonimnog_Autora;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Delo_Anonimnog_Autora = "+Delo_Anonimnog_Autora+"]";
    }
}