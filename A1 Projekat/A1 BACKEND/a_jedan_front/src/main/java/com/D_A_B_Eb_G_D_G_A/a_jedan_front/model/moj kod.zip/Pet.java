package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Pet
{
    private Autorsko_Delo_Prerade Autorsko_Delo_Prerade;

    public Autorsko_Delo_Prerade getAutorsko_Delo_Prerade ()
    {
        return Autorsko_Delo_Prerade;
    }

    public void setAutorsko_Delo_Prerade (Autorsko_Delo_Prerade Autorsko_Delo_Prerade)
    {
        this.Autorsko_Delo_Prerade = Autorsko_Delo_Prerade;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Autorsko_Delo_Prerade = "+Autorsko_Delo_Prerade+"]";
    }
}