package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Autorsko_Delo_Prerade
{

    private String Podaci_O_Originalnom_Autorskom_Delu;

    private String Ime_Autora;

    public String getIme_Autora ()
    {
        return Ime_Autora;
    }

    public void setIme_Autora (String Ime_Autora)
    {
        this.Ime_Autora = Ime_Autora;
    }

    public String getPodaci_O_Originalnom_Autorskom_Delu ()
    {
        return Podaci_O_Originalnom_Autorskom_Delu;
    }

    public void setPodaci_O_Originalnom_Autorskom_Delu (String Podaci_O_Originalnom_Autorskom_Delu)
    {
        this.Podaci_O_Originalnom_Autorskom_Delu = Podaci_O_Originalnom_Autorskom_Delu;
    }

    @Override
    public String toString()
    {
        return "ClassPojo ["+ "Podaci_O_Originalnom_Autorskom_Delu = "+Podaci_O_Originalnom_Autorskom_Delu+ ", Ime_Autora = "+Ime_Autora+"]";
    }
}