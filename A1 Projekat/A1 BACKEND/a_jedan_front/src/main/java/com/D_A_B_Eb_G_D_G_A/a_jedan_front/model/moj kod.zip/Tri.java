package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Tri
{
    private Punomocnik Punomocnik;

    public Punomocnik getPunomocnik ()
    {
        return Punomocnik;
    }

    public void setPunomocnik (Punomocnik Punomocnik)
    {
        this.Punomocnik = Punomocnik;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Punomocnik = "+Punomocnik+"]";
    }
}
