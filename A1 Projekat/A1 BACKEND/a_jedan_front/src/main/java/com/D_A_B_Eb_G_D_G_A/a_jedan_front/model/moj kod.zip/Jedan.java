package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Jedan
{
    private Podnosilac Podnosilac;

    private String Telefonski_Broj;

    private String email;

    public Podnosilac getPodnosilac ()
    {
        return Podnosilac;
    }

    public void setPodnosilac (Podnosilac Podnosilac)
    {
        this.Podnosilac = Podnosilac;
    }

    public String getTelefonski_Broj ()
    {
        return Telefonski_Broj;
    }

    public void setTelefonski_Broj (String Telefonski_Broj)
    {
        this.Telefonski_Broj = Telefonski_Broj;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Podnosilac = "+Podnosilac+", Telefonski_Broj = "+Telefonski_Broj+", email = "+email+"]";
    }
}