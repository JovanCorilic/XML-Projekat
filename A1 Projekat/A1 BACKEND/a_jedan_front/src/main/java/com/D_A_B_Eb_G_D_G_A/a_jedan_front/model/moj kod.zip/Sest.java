package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Sest
{
    private String Podaci_O_Vrsti_Autorskog_Dela;

    public String getPodaci_O_Vrsti_Autorskog_Dela ()
    {
        return Podaci_O_Vrsti_Autorskog_Dela;
    }

    public void setPodaci_O_Vrsti_Autorskog_Dela (String Podaci_O_Vrsti_Autorskog_Dela)
    {
        this.Podaci_O_Vrsti_Autorskog_Dela = Podaci_O_Vrsti_Autorskog_Dela;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Podaci_O_Vrsti_Autorskog_Dela = "+Podaci_O_Vrsti_Autorskog_Dela+"]";
    }
}