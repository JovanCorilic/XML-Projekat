package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Punomocnik
{
    private String Ime;

    private String Prezime;
	
    private Adresa Adresa;

    public String getIme ()
    {
        return Ime;
    }

    public void setIme (String Ime)
    {
        this.Ime = Ime;
    }

    public Adresa getAdresa ()
    {
        return Adresa;
    }

    public void setAdresa (Adresa Adresa)
    {
        this.Adresa = Adresa;
    }

    public String getPrezime ()
    {
        return Prezime;
    }

    public void setPrezime (String Prezime)
    {
        this.Prezime = Prezime;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Ime = "+Ime+", Prezime = "+Prezime+", Adresa = "+Adresa+"]";
    }
}