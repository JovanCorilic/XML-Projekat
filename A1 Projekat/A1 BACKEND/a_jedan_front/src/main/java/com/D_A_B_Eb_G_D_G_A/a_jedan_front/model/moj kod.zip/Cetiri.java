package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Cetiri
{
    private String Alternativni_Naslov;

    private String Naslov;

    public String getAlternativni_Naslov ()
    {
        return Alternativni_Naslov;
    }

    public void setAlternativni_Naslov (String Alternativni_Naslov)
    {
        this.Alternativni_Naslov = Alternativni_Naslov;
    }

    public String getNaslov ()
    {
        return Naslov;
    }

    public void setNaslov (String Naslov)
    {
        this.Naslov = Naslov;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Alternativni_Naslov = "+Alternativni_Naslov+", Naslov = "+Naslov+"]";
    }
}