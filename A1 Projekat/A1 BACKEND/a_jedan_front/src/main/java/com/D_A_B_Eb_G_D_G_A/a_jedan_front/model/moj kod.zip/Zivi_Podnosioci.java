package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Zivi_Podnosioci
{
    private Ziv_Podnosilac[] Ziv_Podnosilac;

    public Ziv_Podnosilac[] getZiv_Podnosilac ()
    {
        return Ziv_Podnosilac;
    }

    public void setZiv_Podnosilac (Ziv_Podnosilac[] Ziv_Podnosilac)
    {
        this.Ziv_Podnosilac = Ziv_Podnosilac;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Ziv_Podnosilac = "+Ziv_Podnosilac+"]";
    }
}
	