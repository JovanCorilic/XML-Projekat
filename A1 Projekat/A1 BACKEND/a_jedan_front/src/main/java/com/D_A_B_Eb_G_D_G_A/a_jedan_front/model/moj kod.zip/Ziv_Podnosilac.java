package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Ziv_Podnosilac
{
    private String Ime;

    private String Prezime;

    private Adresa adresa;

    private String Drzavljanstvo;

    public String getIme ()
    {
        return Ime;
    }

    public void setIme (String Ime)
    {
        this.Ime = Ime;
    }

    public String getDrzavljanstvo ()
    {
        return Drzavljanstvo;
    }

    public void setDrzavljanstvo (String Drzavljanstvo)
    {
        this.Drzavljanstvo = Drzavljanstvo;
    }

    public Adresa getAdresa ()
    {
        return adresa;
    }

    public void setAdresa (Adresa adresa)
    {
        this.adresa = adresa;
    }

    public String getPrezime ()
    {
        return Prezime;
    }

    public void setPrezime (String Prezime)
    {
        this.Prezime = Prezime;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Ime = "+Ime+", Prezime = "+Prezime+", adresa = "+adresa+", Drzavljanstvo = "+Drzavljanstvo+"]";
    }
}