package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Sedam
{
    private String Podaci_O_Formi_Autorskog_Zapisa_Dela;

    public String getPodaci_O_Formi_Autorskog_Zapisa_Dela ()
    {
        return Podaci_O_Formi_Autorskog_Zapisa_Dela;
    }

    public void setPodaci_O_Formi_Autorskog_Zapisa_Dela (String Podaci_O_Formi_Autorskog_Zapisa_Dela)
    {
        this.Podaci_O_Formi_Autorskog_Zapisa_Dela = Podaci_O_Formi_Autorskog_Zapisa_Dela;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Podaci_O_Formi_Autorskog_Zapisa_Dela = "+Podaci_O_Formi_Autorskog_Zapisa_Dela+"]";
    }
}