package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "AJedan")
public class AJedan implements Serializable
{
    private Jedan Jedan;

    private Dva Dva;

    private Tri Tri;

    private Cetiri Cetiri;

    private Pet Pet;

    private Sest Sest;

    private Sedam Sedam;

    private Osam Osam;

    private Devet Devet;

    private Deset Deset;

    private Jedanaest Jedanaest;

    private Dvanaest Dvanaest;

    private String Opis_Autorskog_Dela;

    private String Broj_Prijace;

    private String Datum_Podnosenja;

    public String getDatum_Podnosenja ()
    {
        return Datum_Podnosenja;
    }

    public void setDatum_Podnosenja (String Datum_Podnosenja)
    {
        this.Datum_Podnosenja = Datum_Podnosenja;
    }

    public Devet getDevet ()
    {
        return Devet;
    }

    public void setDevet (Devet Devet)
    {
        this.Devet = Devet;
    }

    public Tri getTri ()
    {
        return Tri;
    }

    public void setTri (Tri Tri)
    {
        this.Tri = Tri;
    }

    public Deset getDeset ()
    {
        return Deset;
    }

    public void setDeset (Deset Deset)
    {
        this.Deset = Deset;
    }

    public Dva getDva ()
    {
        return Dva;
    }

    public void setDva (Dva Dva)
    {
        this.Dva = Dva;
    }

    public Jedan getJedan ()
    {
        return Jedan;
    }

    public void setJedan (Jedan Jedan)
    {
        this.Jedan = Jedan;
    }

    public Cetiri getCetiri ()
    {
        return Cetiri;
    }

    public void setCetiri (Cetiri Cetiri)
    {
        this.Cetiri = Cetiri;
    }

    public Sest getSest ()
    {
        return Sest;
    }

    public void setSest (Sest Sest)
    {
        this.Sest = Sest;
    }

    public Jedanaest getJedanaest ()
    {
        return Jedanaest;
    }

    public void setJedanaest (Jedanaest Jedanaest)
    {
        this.Jedanaest = Jedanaest;
    }

    public String getOpis_Autorskog_Dela ()
    {
        return Opis_Autorskog_Dela;
    }

    public void setOpis_Autorskog_Dela (String Opis_Autorskog_Dela)
    {
        this.Opis_Autorskog_Dela = Opis_Autorskog_Dela;
    }

    public Osam getOsam ()
    {
        return Osam;
    }

    public void setOsam (Osam Osam)
    {
        this.Osam = Osam;
    }

    public Dvanaest getDvanaest ()
    {
        return Dvanaest;
    }

    public void setDvanaest (Dvanaest Dvanaest)
    {
        this.Dvanaest = Dvanaest;
    }

    public String getBroj_Prijace ()
    {
        return Broj_Prijace;
    }

    public void setBroj_Prijace (String Broj_Prijace)
    {
        this.Broj_Prijace = Broj_Prijace;
    }

    public Pet getPet ()
    {
        return Pet;
    }

    public void setPet (Pet Pet)
    {
        this.Pet = Pet;
    }

    public Sedam getSedam ()
    {
        return Sedam;
    }

    public void setSedam (Sedam Sedam)
    {
        this.Sedam = Sedam;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [" +
                "Jedan = "+Jedan+
                ", Dva = "+Dva+
                ", Tri = "+Tri+
                ", Cetiri = "+Cetiri+
                ", Pet = "+Pet+
                ", Sest = "+Sest+
                ", Sedam = "+Sedam+
                ", Osam = "+Osam+
                ", Devet = "+Devet+
                ", Deset = "+Deset+
                ", Jedanaest = "+Jedanaest+
                ", Dvanaest = "+Dvanaest+
                ", Opis_Autorskog_Dela = "+Opis_Autorskog_Dela+
                ", Broj_Prijace = "+Broj_Prijace+
                ", Datum_Podnosenja = "+Datum_Podnosenja+
                "]";
    }
}