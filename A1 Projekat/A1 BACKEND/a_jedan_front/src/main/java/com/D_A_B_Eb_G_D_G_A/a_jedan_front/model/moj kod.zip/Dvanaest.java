package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Dvanaest
{
    private String Prilozi_Uz_Zahtev;

    public String getPrilozi_Uz_Zahtev ()
    {
        return Prilozi_Uz_Zahtev;
    }

    public void setPrilozi_Uz_Zahtev (String Prilozi_Uz_Zahtev)
    {
        this.Prilozi_Uz_Zahtev = Prilozi_Uz_Zahtev;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Prilozi_Uz_Zahtev = "+Prilozi_Uz_Zahtev+"]";
    }
}