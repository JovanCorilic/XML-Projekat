package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Adresa
{
	private String Grad;
	
    private String Ulica;

    private String Broj;

    

    public String getUlica ()
    {
        return Ulica;
    }

    public void setUlica (String Ulica)
    {
        this.Ulica = Ulica;
    }

    public String getBroj ()
    {
        return Broj;
    }

    public void setBroj (String Broj)
    {
        this.Broj = Broj;
    }

    public String getGrad ()
    {
        return Grad;
    }

    public void setGrad (String Grad)
    {
        this.Grad = Grad;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Grad = "+Grad+", Broj = "+Broj+", Ulica = "+Ulica+"]";
    }
}