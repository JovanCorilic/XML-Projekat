package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Anonimni_Podnosioci
{
    private Anoniman_Podnosilac[] Anoniman_Podnosilac;

    public Anoniman_Podnosilac[] getAnoniman_Podnosilac ()
    {
        return Anoniman_Podnosilac;
    }

    public void setAnoniman_Podnosilac (Anoniman_Podnosilac[] Anoniman_Podnosilac)
    {
        this.Anoniman_Podnosilac = Anoniman_Podnosilac;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Anoniman_Podnosilac = "+Anoniman_Podnosilac+"]";
    }
}