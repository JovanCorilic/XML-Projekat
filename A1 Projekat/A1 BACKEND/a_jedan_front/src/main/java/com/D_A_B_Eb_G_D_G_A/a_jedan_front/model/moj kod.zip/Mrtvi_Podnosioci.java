package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Mrtvi_Podnosioci
{
    private Mrtav_Podnosilac[] Mrtav_Podnosilac;

    public Mrtav_Podnosilac[] getMrtav_Podnosilac ()
    {
        return Mrtav_Podnosilac;
    }

    public void setMrtav_Podnosilac (Mrtav_Podnosilac[] Mrtav_Podnosilac)
    {
        this.Mrtav_Podnosilac = Mrtav_Podnosilac;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Mrtav_Podnosilac = "+Mrtav_Podnosilac+"]";
    }
}