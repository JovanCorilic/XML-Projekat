package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Jedanaest
{
    private String Potpis;

    public String getPotpis ()
    {
        return Potpis;
    }

    public void setPotpis (String Potpis)
    {
        this.Potpis = Potpis;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Potpis = "+Potpis+"]";
    }
}
