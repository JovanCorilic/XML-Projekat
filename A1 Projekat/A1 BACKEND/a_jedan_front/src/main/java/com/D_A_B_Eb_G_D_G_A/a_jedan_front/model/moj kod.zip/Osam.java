package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Osam
{
    private Podnosioci Podnosioci;

    public Podnosioci getPodnosioci ()
    {
        return Podnosioci;
    }

    public void setPodnosioci (Podnosioci Podnosioci)
    {
        this.Podnosioci = Podnosioci;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Podnosioci = "+Podnosioci+"]";
    }
}
