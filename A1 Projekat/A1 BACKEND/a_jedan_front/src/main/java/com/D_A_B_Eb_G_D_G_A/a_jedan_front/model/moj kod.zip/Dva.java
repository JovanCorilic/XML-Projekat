package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Dva
{
    private String Znak_Autora;

    public String getZnak_Autora ()
    {
        return Znak_Autora;
    }

    public void setZnak_Autora (String Znak_Autora)
    {
        this.Znak_Autora = Znak_Autora;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Znak_Autora = "+Znak_Autora+"]";
    }
}