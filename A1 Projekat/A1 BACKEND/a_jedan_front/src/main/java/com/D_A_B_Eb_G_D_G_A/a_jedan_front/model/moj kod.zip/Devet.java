package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Devet
{
    private String Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu;

    public String getDa_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu ()
    {
        return Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu;
    }

    public void setDa_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu (String Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu)
    {
        this.Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu = Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu = "+Da_Li_Je_Autorsko_Delo_Stvoreno_U_Radnom_Odnosu+"]";
    }
}