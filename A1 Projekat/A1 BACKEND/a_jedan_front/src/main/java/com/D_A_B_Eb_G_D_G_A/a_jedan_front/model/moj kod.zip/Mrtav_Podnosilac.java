package com.D_A_B_Eb_G_D_G_A.a_jedan_front.model;

public class Mrtav_Podnosilac
{
    private String Ime;

    private String Prezime;

    private String Godina_Smrti;
	
    public String getIme ()
    {
        return Ime;
    }

    public void setIme (String Ime)
    {
        this.Ime = Ime;
    }

    public String getGodina_Smrti ()
    {
        return Godina_Smrti;
    }

    public void setGodina_Smrti (String Godina_Smrti)
    {
        this.Godina_Smrti = Godina_Smrti;
    }

    public String getPrezime ()
    {
        return Prezime;
    }

    public void setPrezime (String Prezime)
    {
        this.Prezime = Prezime;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Ime = "+Ime+", Prezime = "+Prezime+", Godina_Smrti = "+Godina_Smrti+"]";
    }
}
